<?php
	
	global $wpdb;
    $table_name = $wpdb->prefix . "ifsc_lite_db";

	
	$count = 0;
	$count = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name" );
	
  
  if (isset($_POST['oj_ifsccode_delete_db'])) {
		
		global $wpdb;
		
		$wpdb->query("TRUNCATE TABLE $table_name");
		$success_message= "$count IFSC Code Branches Details Data permanently deleted : ";
 }
 

	?>
<style>
.oj-import-box {
	background: #fff;
	margin-top: 20px;
	padding: 20px;
	text-align: center;
}
.oj-import-box h2 {
    font-size: 24px;
    font-weight: normal;
}
.oj-wrapper a{
	color:#b32d2e;
}
</style>
<div class="bootstrap-wrapper">
	<div class="container-fluid">	
		<div id="update_message"> </div>
			<div class="panel with-nav-tabs panel-info">
				<div class="panel-body">
					<center>
						<h2><?php _e('=== IFSC Code Lite  Version 1.0 ===','oj_ifsc_code'); ?></h2>
					</center>
					<div style="padding:10px;" class="notice notice-warning is-dismissible oj-wrapper">
						<span>
							<?php echo wp_kses_post( sprintf( __( 'Before you Empty, please <a href="%1$s" target="%2$s">backup your database</a> first.', 'oj-ifsc-code' ), 'https://wordpress.org/plugins/wp-dbmanager/', '_blank' ) ); ?>
						</span>
					</div>
					
					<?php if(isset($success_message)): ?>
						<div style="padding: 10px;" class="notice notice-success is-dismissible"><?php echo esc_html($success_message); ?></div>
					<?php endif; ?>
					
					<div class="oj-import-box">
						<?php _e( 'There are a total of', 'oj-ifsc-code'); ?> <strong class="attention"><?php echo esc_html($count); ?> </strong> <?php _e( 'IFSC Code Branches Details', 'oj-ifsc-code'); ?>
						
						<form method="post" action="">
							<div class="oj-import-box">
							<h2><?php _e( 'Delete Empty IFSC Code All Branches Data', 'oj-ifsc-code'); ?></h2>
								<input type="submit" name="oj_ifsccode_delete_db" id="oj_ifsccode_delete_db" value="<?php _e( 'Delete IFSC Code!', 'oj-ifsc-code'); ?>" class="button"
								onclick="return confirm('<?php _e( 'Are you sure you want to Delete All IFSC Code Branches ?', 'oj-ifsc-code'); ?>')">	
							</div>
						</form>
					</div>

				</div>
		</div>
	</div>
</div>
