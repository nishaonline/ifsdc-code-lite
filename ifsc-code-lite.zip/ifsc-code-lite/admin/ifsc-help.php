
<style>
.oj-import-box {
	background: #fff;
	margin-top: 20px;
	padding: 20px;
	text-align: center;
}
.oj-import-box h2 {
    font-size: 24px;
    font-weight: normal;
}
.oj-wrapper a{
	color:#b32d2e;
}
</style>
<div class="bootstrap-wrapper">
	<div class="container-fluid">	
		<div id="update_message"> </div>
			<div class="panel with-nav-tabs panel-info">
				<div class="panel-body">
					<center>
						<h2><?php _e('=== IFSC Code Lite  Version 1.0 ===','oj_ifsc_code'); ?></h2>					
						<h3><?php _e('IFSC Code Lite Plugin Chnagelog and Help','oj_ifsc_code'); ?></h3>

						<?php echo wp_kses_post( sprintf( __( '<a href="%1$s" class="button-primary">Need Help</a>', 'oj-ifsc-code' ), IFSC_CODE_LITE_STORE_URL.'ifsc-code-plugin-documentation/' ) ); ?>
					</center>
				</div>
		</div>
	</div>
</div>
