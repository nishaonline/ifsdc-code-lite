<style>
.oj-import-box {
	background: #fff;
	margin-top: 20px;
	padding: 20px;
	text-align: center;
}
.oj-import-box h2 {
    font-size: 24px;
    font-weight: normal;
}
.oj-wrapper a{
	color:#b32d2e;
}
</style>
<div class="bootstrap-wrapper">
	<div class="container-fluid">	
		<div id="update_message"> </div>
			<div class="panel with-nav-tabs panel-info">
				
				
				<div class="panel-body">
					<center>
						<h2><?php _e('=== IFSC Code Lite  Version 1.0 ===','oj_ifsc_code'); ?></h2>
						<h3><?php _e('IFSC Code CSV Importer','oj_ifsc_code'); ?></h3>
					</center>
				
				
	<div style="padding:10px; margin:10px 0px;" class="notice notice-success is-dismissible oj-wrapper">
		<?php echo wp_kses_post( sprintf( __( 'don&#039;t have IFSC Code CSV file <a href="%1$s">Click hare to Download the file</a>', 'oj-ifsc-code' ), IFSC_CODE_LITE_STORE_URL.'wp-content/uploads/ifsc-csv.zip' ) ); ?>	
	</div>	
	
<?php
    if ( isset( $_POST['_oj_ifsccode_branch_import_on_csv'] ) ) {
    check_admin_referer( 'is_oj_ifsccode_branch_import_on_csv', '_oj_ifsccode_branch_import_on_csv' );
        global $wpdb;
		$table_name = $wpdb->prefix . "ifsc_lite_db";
	
        ini_set("auto_detect_line_endings", true);
        //start processing the CSV
        if (!empty($_FILES['import_bank']['name'])) {
            // Setup settings variables
            $filename = $_FILES['import_bank']['tmp_name'];
            $file_handle = fopen($filename,"r");
            $i=0;
            $imported = 0;
            $failedusers = array();
            $successusers = array();
            while (!feof($file_handle) ) {
                $block = 0;
                $check = 0;
                $line_of_text = fgetcsv($file_handle, 1024);
                // Let's make sure fields have data and it is not line 1
                if(!empty($line_of_text[0])) {
                    $i++;
                    if($i > 1 && $i < 80000) {
                    $imported++;    
                        //start new import
						
						$bank = $line_of_text[0];
                        $ifsc = $line_of_text[1];
                        $branch = $line_of_text[2];
                        $address = $line_of_text[3];
						$city = $line_of_text[4];
						$district = $line_of_text[5];
						$state = $line_of_text[6];
						$contact = $line_of_text[7];
						
						$oj_bank = ucwords(strtolower($bank));
						$oj_branch = ucwords(strtolower($branch));
						$oj_city = ucwords(strtolower($city));
						$oj_state = ucwords(strtolower($state));
					  

						$wpdb->insert($table_name, array(
						'oj_bank' => sanitize_text_field($bank),
						'oj_bank_slug' => sanitize_title($bank),
						'oj_ifsc' => sanitize_text_field($ifsc),
						'oj_branch' => sanitize_text_field($branch),
						'oj_branch_slug' => sanitize_title($branch),
						'oj_address' => sanitize_text_field($address),
						'oj_contact' => sanitize_text_field($contact),
						'oj_city' => sanitize_text_field($city),
						'oj_city_slug' => sanitize_title($city),
						'oj_district' => sanitize_text_field($district),
						'oj_state' => sanitize_text_field($state),
						'oj_state_slug' => sanitize_title($state)
						));
						
					
                       echo esc_html('INSERTED = ' .$bank . ' ' . $branch . ' ' . $ifsc); 
					   echo '<br />';
					
                    }
                }
            }
        fclose($file_handle);
			$success_message= "".$imported." IFSC Code Branches Data Inserted : ";
       
        } else {
           $error_message= "Invalid Extension";
        }
    }
    ?>
		
		<?php if(isset($success_message)){ ?>
			<div style="padding: 10px; margin:10px 0px;" class="notice notice-success is-dismissible">
				<?php echo esc_html($success_message); ?>
			</div>
		<?php } ?>
		<?php if(isset($error_message)){ ?>
			<div style="padding: 10px; margin:10px 0px;" class="notice notice-warning is-dismissible">
				<?php echo esc_html($error_message); ?>
			</div>
		<?php } ?>
		
		<div class="oj-import-content">
		<div style="padding:10px; margin:10px 0px;" class="notice notice-warning is-dismissible oj-wrapper">
		<?php esc_html_e( 'If you want to import full IFSC Code Branch Details CSV file then first empty ifsc code database table', 'oj_ifsc_code' );?><a href="<?php echo admin_url('admin.php?page=ifsc-lite-db-clean')?>"> <?php esc_html_e( 'Go To Database Clean Tab', 'oj_ifsc_code' );?></a> 
	</div>	
			<form method="post" enctype="multipart/form-data">
				<div class="oj-import-box">
				<h2><?php _e('Import IFSC Code CSV File only','oj_ifsc_code'); ?></h2>
					<center>
						<input type="file" name="import_bank" id="import_bank" class="oj-import-file">
						<br><br>
						<?php wp_nonce_field( 'is_oj_ifsccode_branch_import_on_csv', '_oj_ifsccode_branch_import_on_csv' ); ?>
						<input type="submit" value="<?php _e('Import!','oj_ifsc_code'); ?>" class="oj-import-input button-primary">
					</center>				
				</div>
			</form>
		</div>

				</div>
					
					
					
		</div>
	</div>
</div>
