<?php
/*
    Exit if accessed directly
*/
    if ( ! defined( 'ABSPATH' ) ) exit;
    if ( ! class_exists( 'LITE_Ifsc_Code' ) ) {

      class LITE_Ifsc_Code extends IFSC_Base_Class{

        /**
         * Setup the plugin data
         *
         * @since 1.0.0
        */
        public function __construct() {

         $this->add_action( 'admin_menu', 'ifsc_code_admin_menus');
		 $this->add_action( 'wp_head', 'ifsc_add_css_code');
		 $this->add_action('admin_enqueue_scripts', 'ifsc_code_admin_styles');
		 
		 $this->add_action( 'wp_enqueue_scripts', 'ifsc_front_styles');
		  $this->register_shortcode('ifsc-details', 'online_ifsc_lite_db_shortcode');
         
          $this->add_filter( 'document_title_parts', 'online_ifsc_change_document_title_parts' );
          $this->add_filter( 'pre_get_document_title', 'online_ifsc_change_document_title', 999,1 );
          $this->add_action( 'init','ifsc_rewrite_rules');
          $this->add_action( 'admin_init', 'ifsc_flush_rewrite');


        }

        public function ifsc_flush_rewrite() {

            if ( !get_option('plugin_settings_have_changed') ) {
                flush_rewrite_rules();
                update_option('plugin_settings_have_changed', false);
            }
        }
		
		public function ifsc_front_styles()
        {
			if (is_page('ifsc-code')) {
            ///$this->enqueue_style('ifsc-custom-style', plugins_url('css/custom.css', dirname(__FILE__)), false, IFSC_CPDE_LITE_VERSION);
			}
        }
		
		 public function ifsc_add_css_code()
        {
            if (is_page('ifsc-code')) {
				?>
<style>
.oj-form-default {
    background: #fff;
    background-position-x: 0%;
    background-position-y: 0%;
    background-repeat: repeat;
    padding: 15px;
    box-shadow: inset 0 0 0 15px #f5f5f5;
    font-size: .95em;
    background-repeat: no-repeat;
    background-position: 100%;
}.oj-form-default .oj-form-group {
    margin-left: 0;
    margin-right: 0;
}form .oj-form-group {
    margin-bottom: 1.5rem;
}.oj-row {
    display: flex;
    flex-wrap: wrap;
}.oj-form-default .control-label {
    margin-bottom: 0;
    padding-top: 7px;
}.oj-row > .control-label {
    text-align: left;
}.pdt-15{
	padding-top: 15px;
}.oj-left-2 {
    width: 30%;
    position: relative;
    min-height: 1px;
    padding-left: 15px;
    padding-right: 5px;
}.oj-left-2 img {
	float:right;
}.oj-control-label {
    font-weight: 400;
}.oj-center-8 {
    position: relative;
    width: 100%;
    min-height: 1px;
    padding-left: 15px;
    padding-right: 15px;
}.form-control {
    width: 100%;
    height: 42px;
    padding: 12px 12px;
}.oj-table-responsive {
    overflow-x: auto;
    min-height: .01%;
	margin-top: 15px;
}.oj-table {
    width: 100%;
    max-width: 100%;
    margin-bottom: 1rem;
    background-color: transparent;
}.oj-table-striped tbody tr:nth-of-type(odd){
    background-color: rgba(245, 247, 250, .5)
}.oj-table th,
.oj-table td{
    padding: .4rem .5rem;
    border-bottom: 1px solid #e3ebf3;
    vertical-align: top
}.oj-table th {
    font-weight: 700
}.oj-table-bordered th,
.oj-table-bordered td {
    border: 1px solid #e3ebf3
}#ifsctext{
    float: right;
    text-align: center;
    border: 1px solid #EEEEEE;
    padding: 3px;
    width: 20%;
}@media (min-width: 768px){.oj-center-8 {
    flex: 0 0 70%;
    max-width: 70%;
}}@media (max-width: 768px){
.oj-left-2, .oj-rig-2{
    display: none;
}.oj-form-default{
    padding: 0;
	box-shadow: inset 0 0 0 1px #f5f5f5;
}}
              </style>
            <?php }
        }

        /**
         * Add Admin Menu 
         *
         * @access public
         * @param void
         * @return void
         * @since 1.0.0
        */
		
        public static function ifsc_code_admin_menus() {
			
          add_menu_page( IFSC_CPDE_LITE_PLUGIN_NAME, __( IFSC_CPDE_LITE_PLUGIN_NAME , 'ifsc-lite-import' ), 'manage_options', 'ifsc-lite-import', array(
           __CLASS__,
           'ifsc_code_plugin_import_csv'

         ), plugins_url( 'images/ifsc-menu.png', dirname(__FILE__)));
		 
		 add_submenu_page('ifsc-lite-import', 'Import', 'Import', 'manage_options', 'ifsc-lite-import', [__CLASS__, 'ifsc_code_plugin_import_csv']);
		 
		 add_submenu_page('ifsc-lite-import', 'DB Clean', 'DB Clean', 'manage_options', 'ifsc-lite-db-clean', [__CLASS__, 'ifsc_code_plugin_db_clean']);
		 
		 add_submenu_page('ifsc-lite-import', 'Help', 'Help', 'manage_options', 'ifsc-lite-help', [__CLASS__, 'ifsc_plugin_help_page']);
		 
		 
		  
        }
        /**
         * Add Settings Page
         *
         * @access public
         * @param void
         * @return void
         * @since 1.0.0
        */
        public static function ifsc_code_plugin_import_csv() {

            require_once IFSC_CPDE_LITE_ROOT_PATH . '/admin/ifsc-import-csv.php';
        }
		
		public static function ifsc_code_plugin_db_clean() {

            require_once IFSC_CPDE_LITE_ROOT_PATH . '/admin/ifsc-db-clean.php';
        }
		 public static function ifsc_plugin_help_page() {

            require_once IFSC_CPDE_LITE_ROOT_PATH . '/admin/ifsc-help.php';
        }
 
      public function online_ifsc_change_document_title($title)
        {

          

            if (is_page('ifsc-code')) {
				
			$bank = get_query_var('bank');			
            $state = get_query_var('state');
			$city = get_query_var('city');
			$branch = get_query_var('branch');
			
			$bankTB = ucwords(str_replace('-', ' ', $bank));
            $stateTB = ucwords(str_replace('-', ' ', $state));
            $cityTB = ucwords(str_replace('-', ' ', $city));
            $branchTB = ucwords(str_replace('-', ' ', $branch));
                if ($branch) {
                    $newtitle = "$bankTB $branchTB $cityTB IFSC Code";
                } elseif ($city) {
                    $newtitle = "$bankTB $cityTB IFSC Code";
                } elseif ($state) {
                    $newtitle = "$bankTB $stateTB IFSC Code";
                } elseif ($bank) {
                    $newtitle = "$bankTB IFSC Code";
                } else {
                    $newtitle = get_bloginfo('name');
                }
            } else {
                return $title;
            }
        }
        public function online_ifsc_change_document_title_parts($title_parts)
        {

           

            if (is_page('ifsc-code')) {
				
				$bank = get_query_var('bank');			
            $state = get_query_var('state');
			$city = get_query_var('city');
			$branch = get_query_var('branch');
			
            $bankTB = ucwords(str_replace('-', ' ', $bank));
            $stateTB = ucwords(str_replace('-', ' ', $state));
            $cityTB = ucwords(str_replace('-', ' ', $city));
            $branchTB = ucwords(str_replace('-', ' ', $branch));
			
                if (get_query_var('branch')) {
                    $title_parts['title'] = "$bankTB $branchTB IFSC Code";
                } elseif (get_query_var('city')) {
                    $title_parts['title'] = "$bankTB $cityTB IFSC Code";
                } elseif (get_query_var('state')) {
                    $title_parts['title'] = "$bankTB $stateTB IFSC Code";
                } elseif (get_query_var('bank')) {
                    $title_parts['title'] = "$bankTB IFSC Code";
                } else {
                    $title_parts['title'];
                }
            }return $title_parts;
        }

          public function online_ifsc_lite_db_shortcode($atts)
        {
			if ( is_page( 'ifsc-code' ) ) {
			$ifsc_url = 'ifsc';
            $bank = get_query_var('bank');			
            $state = get_query_var('state');
			$city = get_query_var('city');
			$branch = get_query_var('branch');
            $bankTB = strtoupper(str_replace('-', ' ', $bank));
            $stateTB = strtoupper(str_replace('-', ' ', $state));
            $cityTB = strtoupper(str_replace('-', ' ', $city));
            $branchTB = strtoupper(str_replace('-', ' ', $branch));

            
			$home_url = 'online';
            $baseurl = home_url('ifsc-code/');
            $bankurl = home_url('ifsc-code/' . $bank . '/');
            $stateurl = home_url('ifsc-code/' . $bank . '/' . $state . '/');
            $cityurl = home_url('ifsc-code/' . $bank . '/' . $state . '/' . $city . '/');
			$branch_url = $bank . '/' . $state . '/' . $city . '/'.$branch;

            global $wpdb;
            $table_name = $wpdb->prefix . "ifsc_lite_db";

            if ($branch) {
				
				global $post, $wpdb;
			$table_name = $wpdb->prefix . "ifsc_lite_db";
		
			
			
			$results = $wpdb->get_results("SELECT DISTINCT oj_bank, oj_bank_slug, oj_ifsc, oj_branch, oj_branch_slug, oj_address, oj_contact, oj_city, oj_city_slug, oj_district, oj_state, oj_state_slug from $table_name WHERE oj_bank_slug='$bank' AND oj_state_slug='$state' AND oj_city_slug='$city' AND oj_branch_slug='$branch' LIMIT 1");
					
                    $oj_bank = $results[0]->oj_bank ?? "";
                    $oj_state =$results[0]->oj_state ?? "";
                    $oj_city = $results[0]->oj_city ?? "";
                    $oj_district = $results[0]->oj_district ?? "";
                    $oj_branch = $results[0]->oj_branch ?? "";
                    $oj_ifsc = $results[0]->oj_ifsc ?? "";
					$oj_code = 'code.com';
                    $oj_micr = $results[0]->oj_micr?? "";
                    $oj_address = $results[0]->oj_address ?? "";
                    $oj_mobile = $results[0]->oj_mobile ?? "";
					
					$site_url = $home_url.$ifsc_url.$oj_code.'/';
                

                require_once IFSC_CPDE_LITE_ROOT_PATH . '/templates/details.php';
            } elseif ($city) {
				
				 $allbranchs = $wpdb->get_results("SELECT DISTINCT oj_branch, oj_branch_slug from $table_name WHERE oj_bank_slug='$bank' AND oj_state_slug='$state' AND oj_city_slug='$city' ORDER BY oj_branch ASC");
				
                require_once IFSC_CPDE_LITE_ROOT_PATH . '/templates/branch.php';
            } elseif ($state) {
                $allcitys = $wpdb->get_results("SELECT DISTINCT oj_city, oj_city_slug from $table_name WHERE oj_bank_slug='$bank' AND oj_state_slug='$state' ORDER BY oj_city ASC");

                require_once IFSC_CPDE_LITE_ROOT_PATH . '/templates/city.php';
            } elseif ($bank) {
                $allstates = $wpdb->get_results("SELECT DISTINCT oj_state, oj_state_slug from $table_name WHERE oj_bank_slug='$bank' ORDER BY oj_state ASC");

                require_once IFSC_CPDE_LITE_ROOT_PATH . '/templates/state.php';
            } else {
                $allbanks = $wpdb->get_results("SELECT DISTINCT oj_bank, oj_bank_slug from $table_name ORDER BY oj_bank ASC");
			

                require_once IFSC_CPDE_LITE_ROOT_PATH . '/templates/bank.php';

            }
			?>
 
             <script>function formSubmit(selector) {formSelectUrl = selector.value;window.location.href = formSelectUrl;}</script>
			 
              <?php 
        }
		}
         
  
		public function ifsc_code_admin_styles(){
        
			wp_enqueue_style( 'oj-ifsc-style', plugins_url( 'admin/files/css/ic-bootstrap.css', IFSC_CODE_LITE_FILE ) );
			
			
        }
        /**
         * Add rewrite tags and rules
         */
        public function ifsc_rewrite_rules() {
			
			add_rewrite_rule('ifsc-code/([^/]+)/([^/]+)/([^/]+)/([^/]+)', 'index.php?pagename=ifsc-code&bank=$matches[1]&state=$matches[2]&city=$matches[3]&branch=$matches[4]', 'top');
			
			add_rewrite_rule('ifsc-code/([^/]+)/([^/]+)/([^/]+)', 'index.php?pagename=ifsc-code&bank=$matches[1]&state=$matches[2]&city=$matches[3]', 'top');
			
            add_rewrite_rule('ifsc-code/([^/]+)/([^/]+)', 'index.php?pagename=ifsc-code&bank=$matches[1]&state=$matches[2]', 'top');
			
            add_rewrite_rule('ifsc-code/([^/]+)', 'index.php?pagename=ifsc-code&bank=$matches[1]', 'top');

			add_rewrite_tag('%bank%', '([^&]+)');
            add_rewrite_tag('%state%', '([^&]+)');
            add_rewrite_tag('%city%', '([^&]+)');
            add_rewrite_tag('%branch%', '([^&]+)');
        }
        /**
         * Save options after activate plugin
         *
         * @access public
         * @param void
         * @return void
         * @since 1.0.0
        */
        public static function ifsc_code_install_plugin() {
         $ifsc_detail = array(
                'post_title' => wp_strip_all_tags('IFSC Code '),
                'post_content' => '[ifsc-details]',
                'post_status' => 'publish',
                'post_author' => 1,
                'post_type' => 'page',
             );
          
          if (!post_exists(wp_strip_all_tags('IFSC Code'))) {
                wp_insert_post($ifsc_detail);
            } 
          //flush_rewrite_rules();
		  
			global $wpdb;
            $table_name = $wpdb->prefix . "ifsc_lite_db";
		
			$branch_sql = "CREATE TABLE " . $table_name . " (
			  id int(11) NOT NULL AUTO_INCREMENT,
			  oj_bank VARCHAR(100) NOT NULL,
			  oj_bank_slug VARCHAR(100) NOT NULL,
			  oj_ifsc VARCHAR(11) NOT NULL,
			  oj_branch VARCHAR(255) NOT NULL,
			  oj_branch_slug VARCHAR(255) NOT NULL,
			  oj_address VARCHAR(255) NOT NULL,
			  oj_contact VARCHAR(100) DEFAULT NULL,
			  oj_city VARCHAR(100) NOT NULL,
			  oj_city_slug VARCHAR(100) NOT NULL,
			  oj_district VARCHAR(100) NOT NULL,
			  oj_state VARCHAR(100) NOT NULL,
			  oj_state_slug VARCHAR(100) NOT NULL,
			  oj_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
			  PRIMARY KEY (id)
			);";
			
			// ABSPATH 
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($branch_sql); 

        }
        /**
         * Delete options after activate plugin
         *
         * @access public
         * @param void
         * @return void
         * @since 1.0.0
        */ 
        public static function ifsc_code_uninstall_plugin() {


        }
      }
}