<div class="oj-form-default">
   <form>
      <div class="pdt-15">
         <div class="oj-form-group oj-row">
            <div class="oj-left-2">
               <label class="oj-control-label"><?php esc_html_e('Select Bank','oj_ifsc_code'); ?></label>
                <a href="<?php echo $baseurl; ?>" class="reset"><img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/3.png'; ?>"></a> 
            </div>
            <div class="oj-center-8">
               <select class="form-control ">
                   <option selected>
                        <?php echo esc_html($bankTB); ?>
                    </option>
                 
               </select>
            </div>
           
         </div>
         <div class="oj-form-group oj-row">
            <div class="oj-left-2">
               <label class="oj-control-label"><?php esc_html_e('Select State','oj_ifsc_code'); ?></label>
               <a href="<?php echo $bankurl; ?>" class="reset"><img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/3.png'; ?>"></a> 
            </div>
            <div class="oj-center-8">
               <select class="form-control">
                  <option selected>
                       <?php echo esc_html($stateTB); ?>
                   </option>
               </select>
            </div>
           
         </div>
		 <div class="oj-form-group oj-row">
            <div class="oj-left-2">
               <label class="oj-control-label"><?php esc_html_e('Select City','oj_ifsc_code'); ?></label>
               <a href="<?php echo $stateurl; ?>" class="reset"><img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/3.png'; ?>"></a> 
            </div>
            <div class="oj-center-8">
               <select class="form-control">
                  <option selected>
                        <?php echo esc_html($cityTB); ?>
                   </option>
               </select>
            </div>
           
         </div>

         <div class="oj-form-group oj-row">
            <div class="oj-left-2">
               <label class="oj-control-label"><?php esc_html_e('Select Branch','oj_ifsc_code'); ?></label>
               <img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/2.png'; ?>">  
            </div>
            <div class="oj-center-8">
				<select class="form-control " onchange="formSubmit(this);">
					<option><?php esc_html_e('Select a Branch','oj_ifsc_code'); ?></option>
					 <?php foreach($allbranchs as $result) { ?>
					 <option value=" <?php echo esc_html($cityurl.$result->oj_branch_slug);?>">
						<?php echo esc_html($result->oj_branch);?>
					 </option>
					 <?php } ?>
				</select>
            </div>
          
         </div>
      </div>
   </form>

</div>

