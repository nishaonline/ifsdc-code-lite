<h2><?php echo ucwords(strtolower(esc_html("$oj_bank  $oj_branch $oj_state  "))); ?> <?php esc_html_e('IFSC Code','oj_ifsc_code'); ?></h2>
<div class="oj-form-default">
   <form>
      <div class="pdt-15">
         <div class="oj-form-group oj-row">
            <div class="oj-left-2">
               <label class="oj-control-label"><?php esc_html_e('Select Bank','oj_ifsc_code'); ?></label>
                <a href="<?php echo esc_html($baseurl); ?>" class="reset"><img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/3.png'; ?>"></a> 
            </div>
            <div class="oj-center-8">
               <select class="form-control ">
                   <option selected>
                                    <?php echo esc_html($bankTB); ?>
                            </option>
                 
               </select>
            </div>
           
         </div>
         <div class="oj-form-group oj-row">
            <div class="oj-left-2">
               <label class="oj-control-label"><?php esc_html_e('Select State','oj_ifsc_code'); ?></label>
               <a href="<?php echo $bankurl; ?>" class="reset"><img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/3.png'; ?>"></a> 
            </div>
            <div class="oj-center-8">
               <select class="form-control ">
                   
                  <option selected>
                                    <?php echo esc_html($stateTB); ?>
                                </option>
               </select>
            </div>
           
         </div>
		 <div class="oj-form-group oj-row">
            <div class="oj-left-2">
               <label class="oj-control-label"><?php esc_html_e('Select City','oj_ifsc_code'); ?></label>
               <a href="<?php echo esc_html($stateurl); ?>" class="reset"><img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/3.png'; ?>"></a> 
            </div>
            <div class="oj-center-8">
               <select class="form-control ">
                   
                  <option selected>
                                    <?php echo esc_html($cityTB); ?>
                                </option>
               </select>
            </div>
           
         </div>

         <div class="oj-form-group oj-row">
            <div class="oj-left-2">
               <label class="oj-control-label"><?php esc_html_e('Select Branch','oj_ifsc_code'); ?></label>
              <a href="<?php echo esc_html($cityurl); ?>" class="reset"><img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/3.png'; ?>"></a>  
            </div>
            <div class="oj-center-8">
              <select class="form-control ">
                   
                  <option selected>
                                    <?php echo esc_html($branchTB); ?>
                                </option>
               </select>
            </div>
           
         </div>
      </div>
   </form>

</div>

					<div class="oj-table-responsive">                   
                        <table class="oj-table oj-table-bordered oj-table-striped">
                           
                                 <tbody>
                                    <tr>
                                       <td><?php esc_html_e('Bank Name','oj_ifsc_code'); ?></td>
                                       <td class="word-break-codecyan">
                                          <a href="<?php echo esc_html($bankurl); ?>"><?php echo esc_html($oj_bank); ?></a>
                                       </td>
                                    </tr>
									 <tr>
                                       <td><?php esc_html_e('IFSC Code','oj_ifsc_code'); ?></td>
                                       <td class="little-medium">
                                          <strong><?php echo esc_html($oj_ifsc); ?></strong> <button class="button copybtn" type="button"><?php esc_html_e('Copy','oj_ifsc_code'); ?></button>
										  <input type="text" value="<?php  echo esc_html($oj_ifsc); ?>" id="ifsctext" readonly>
                                       </td>
                                    </tr>
									 <tr>
                                       <td><?php esc_html_e('MICR Code','oj_ifsc_code'); ?></td>
                                       <td>
                                          <?php if (!empty($oj_micr)) { echo esc_html($oj_micr); }else{ echo 'Not Available'; }?>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td><?php esc_html_e('Branch','oj_ifsc_code'); ?></td>
                                       <td class="little-medium">
                                          <a href="https://<?php echo esc_html($site_url.$branch_url);?>"><?php echo esc_html($oj_branch); ?></a>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td><?php esc_html_e('State','oj_ifsc_code'); ?></td>
                                       <td>
                                          <a href="<?php echo esc_html($stateurl); ?>"><?php echo esc_html($oj_state); ?></a>
                                    </tr>
                                    <tr>
                                       <td><?php esc_html_e('City','oj_ifsc_code'); ?></td>
                                       <td>
                                          <a href="<?php echo esc_html($cityurl); ?>"><?php echo esc_html($oj_city); ?></a>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td><?php esc_html_e('District','oj_ifsc_code'); ?></td>
                                       <td class="little-medium">
                                          <?php echo esc_html($oj_district); ?>
                                       </td>
                                    </tr>
									 <tr>
                                       <td><?php esc_html_e('Address','oj_ifsc_code'); ?></td>
                                       <td class="word-break-codecyan">
                                           <?php echo esc_html($oj_address); ?>
                                       </td>
                                    </tr>
                                   
                                    <tr>
                                       <td><?php esc_html_e('Branch Code','oj_ifsc_code'); ?></td>
                                       <td>
                                          <?php echo substr($oj_ifsc, -6); ?> <small><?php esc_html_e('(Last six characters of IFSC code represent Branch code.)','oj_ifsc_code'); ?></small>
                                       </td>
                                    </tr>
                                   
                                    <tr>
                                       <td><?php esc_html_e('Contact Phone','oj_ifsc_code'); ?></td>
                                       <td>
									    <?php if (!empty($oj_mobile)) { echo esc_html($oj_mobile); }else{ esc_html_e('Not Available','oj_ifsc_code'); }?>
                                        
                                       </td>
                                    </tr>
                                    
                                 </tbody>
                              </table>
                              
                        
                    </div>

			
<script>var copyTextareaBtn = document.querySelector('.copybtn');
copyTextareaBtn.addEventListener('click', function(event) {
  var copyTextarea = document.querySelector('#ifsctext');
  copyTextarea.focus();
  copyTextarea.select();

  try {
    var successful = document.execCommand('copy');
    var msg = successful ? 'successful' : 'unsuccessful';
    console.log('Copying text command was ' + msg);
  } catch (err) {
    console.log('Oops, unable to copy');
  }
});</script>