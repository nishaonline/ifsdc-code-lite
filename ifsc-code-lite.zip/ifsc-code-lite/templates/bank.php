<div class="oj-form-default">
   <form>
      <div class="pdt-15">
         <div class="oj-form-group oj-row">
            <div class="oj-left-2">
               <label class="oj-control-label"><?php esc_html_e('Select Bank','oj_ifsc_code'); ?></label>
               <img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/2.png'; ?>"> 
            </div>
            <div class="oj-center-8">
               <select class="form-control " onchange="formSubmit(this);">
                  <option class="select"><?php esc_html_e('Select a Bank','oj_ifsc_code'); ?></option>
				      <?php
                foreach($allbanks as $result) {
                ?>
                <option value="<?php echo esc_html($baseurl.$result->oj_bank_slug); ?>">
				   <?php echo esc_html($result->oj_bank); ?>
				   
				   
				   
                </option>
                <?php
                }
				
                ?>
				
               </select>
            </div>
           
         </div>
         <div class="oj-form-group oj-row">
            <div class="oj-left-2">
               <label class="oj-control-label"><?php esc_html_e('Select State','oj_ifsc_code'); ?></label>
               <img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/2.png'; ?>"> 
            </div>
            <div class="oj-center-8">
               <select disabled class="form-control " onchange="formSubmit(this);">
                  <option class="select"><?php esc_html_e('Select a State','oj_ifsc_code'); ?></option>
               </select>
            </div>
           
         </div>
         <div class="oj-form-group oj-row">
            <div class="oj-left-2">
               <label class="oj-control-label"><?php esc_html_e('Select City','oj_ifsc_code'); ?></label>
               <img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/2.png'; ?>">  
            </div>
            <div class="oj-center-8">
               <select disabled class="form-control " onchange="formSubmit(this);">
                  <option class="select"><?php esc_html_e('Select a City','oj_ifsc_code'); ?></option>
               </select>
            </div>
          
         </div>
         <div class="oj-form-group oj-row">
            <div class="oj-left-2">
               <label class="oj-control-label"><?php esc_html_e('Select Branch','oj_ifsc_code'); ?></label>
               <img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . 'images/2.png'; ?>">  
            </div>
            <div class="oj-center-8">
               <select disabled class="form-control" onchange="formSubmit(this);">
                  <option class="select"><?php esc_html_e('Select a Branch','oj_ifsc_code'); ?></option>
               </select>
            </div>
           
         </div>
      </div>
   </form>
  
  
</div>
