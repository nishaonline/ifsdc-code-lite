<?php 
/*
Plugin Name: IFSC Code Lite.
Plugin URI: https://www.nishaonline.net/product/ifsc-code-pro-wordpress-plugin/
Description: Bank Branch IFSC Code Finder Wordpress plugin to find the Indian Banks States Citys IFSC/MICR Codes, Address, All Banks Branches in India, for NEFT, RTGS, ECS Transactions. It contains all the latest data direct from RBI, includes all the banks and their ifsc codes.

Version: 1.0
Author: Nisha Online
Author URI: https://www.nishaonline.net/
Text Domain: ifsc-code-lite
Domain Path: lang
*/
/*
  *Exit if accessed directly
*/
if ( ! defined( 'ABSPATH' ) ) exit;
    if( ! defined( 'IFSC_CPDE_LITE_PLUGIN_NAME' )){

        define( 'IFSC_CPDE_LITE_PLUGIN_NAME', 'IFSC CODE' );
    }
    if( ! defined( 'IFSC_CPDE_LITE_VERSION' )){ 
        define( 'IFSC_CPDE_LITE_VERSION', '1.0');
    }  
    if( ! defined( 'IFSC_CPDE_LITE_ROOT_PATH' )){
        define( 'IFSC_CPDE_LITE_ROOT_PATH', dirname(__FILE__) );
    }  
	define( 'IFSC_CODE_LITE_STORE_URL', 'https://www.nishaonline.net/' );
	define('IFSC_CODE_LITE_FILE', __FILE__);
	
    /*
     * Load the required classes 
    */
    include_once 'classes/ifsc-base-class.php';  
    include_once 'classes/ifsc-main-class.php';        
    $ifsc_code = new LITE_Ifsc_Code();    
    add_filter( 'plugin_action_links_'.plugin_basename( __FILE__ ),'ifsc_action_links' );
    function ifsc_action_links( $links ){
        $settings_link = array(
           '<a href="' . admin_url( '?page=ifsc-lite-settings' ) . '" style="color:#df003b;">Settings</a>',
           '<a href="https://www.nishaonline.net/product/ifsc-code-pro-wordpress-plugin/" style="color:#11967A;" target="_blank"> Upgrade To Pro </a>',
           '<a href="https://www.nishaonline.net/ifsc-code-plugin-documentation/" style="color:#11967A;" target="_blank"> Need Help </a>',
           );
        return array_merge( $links, $settings_link );
    }
register_activation_hook( __FILE__, array( $ifsc_code, 'ifsc_code_install_plugin' ) );
register_deactivation_hook( __FILE__, array( $ifsc_code, 'ifsc_code_uninstall_plugin' ) );